unset GEM_HOME
